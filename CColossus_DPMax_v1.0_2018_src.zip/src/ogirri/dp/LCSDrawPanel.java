package ogirri.dp;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.util.Map;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

/**
 * @author Desmond Ogirri
 * copyright 2009. All rights reserved.
 */


public class LCSDrawPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2638337869709429600L;
	private LCSCell[][] lcsMatrix;
	private String strSeq1;
	private String strSeq2;
	
	private Dimension area;
	private Graphics gr;
	private Graphics2D g2d;
	private JScrollPane scroller;
	private Dimension area2;
	
	
	public LCSDrawPanel(){
		super();
	}
	
	public LCSDrawPanel(LCSCell[][] matrix, String strSeq1, String strSeq2){
		super();
		this.lcsMatrix = matrix;
		this.strSeq1 = strSeq1;
		this.strSeq2 = strSeq2;
		setOpaque(true);
		/*
		area = new Dimension(3000, 3000);
		area2 = Toolkit.getDefaultToolkit().getScreenSize();
		scroller  = new JScrollPane(this);
		scroller.setPreferredSize(area);
		this.setPreferredSize(area2);
		this.setMinimumSize(area);
		setLayout(new BorderLayout());
		add(new JLabel("THIS IS A LCS TEST LABEL"), BorderLayout.NORTH);
		*/
		//scroller();
	}
	
	public void paintComponent(Graphics gee){
		super.paintComponent(gee);
		gr = gee;
		drawMatrix(lcsMatrix, strSeq1, strSeq2);

		scroller();
	}

	
	public void drawMatrix(LCSCell[][] matrix, String strSeq1, 
			String strSeq2){
		
		if (matrix == null || strSeq1 == null || strSeq2 == null)
			return;
		int x = 30;
		int y = 30;
		int x1 = 0;
		int x2 = 0;
		int y1 = 0;
		int y2 = 0;
		int x3 = 0;
		int y3 = 0;
		int width = 50;
		int height = 50;
		int row;
		int col;
		String score;
		Stroke prevStk;
		Stroke boldStk = new BasicStroke(2f);
		String seq = "";
		Map<String, LCSCell> prevCellMap = null;
		
		area = new Dimension();
		//gr = getGraphics();
		g2d = (Graphics2D)gr;
	   for (row = 0; row < matrix.length; row++) {
		  
		  // y += 50;
		      for (col = 0; col < matrix[0].length; col++) {
		    	 
		         LCSCell currentCell = matrix[row][col];
		         LCSCell prevCell = currentCell.getPrevCell();
		         prevCellMap = currentCell.getPrevCellMap();
		        
				 //if the prev cell is null just draw the current cell
		         if (prevCell == null)
		         {
		        	 g2d.drawRect(x, y, width, height);
		         }
		         else //draw the currentcell and get the direction of the 
		        	 //prevcell so we can draw arrows pointing to it
		        	 //and then draw the score and the sequence chars
		        	 //
		         {
		        	 g2d.drawRect(x, y, width, height);
		        	 prevStk = g2d.getStroke();
		        	 //if(prevCell.isCellAbove(currentCell)){
		        	 if(prevCellMap.get(Constant.CELL_ABOVE) != null) {
		        	 	x1 = x + width;
		        	 	y1 = y + 7;
		        	 	x2 = x1;
		        	 	y2 = y + height - 7;
		        	 	x1 = x1 - 5;
		        	 	x2 = x2 - 5;
		        	 	if(row != 0 && col != 0)
			        	 {
				        	 g2d.setStroke(boldStk);
					         g2d.drawLine(x1, y1, x2, y2);
					         //now draw the arrows
					         x2 = x1 - 5;
					         y2 = y1 + 5;
					         x3 = x1 + 5;
					         y3 = y1 + 5;
					         g2d.drawLine(x1, y1, x2, y2);
					         g2d.drawLine(x1, y1, x3, y3);
				        	 g2d.setStroke(prevStk);
			        	 }
		        	 	
		        	 }
		        	 //if(prevCell.isCellToLeft(currentCell)){
		        	 if(prevCellMap.get(Constant.CELL_TO_LEFT) != null) {
			        	 	x1 = x + 10;
			        	 	y1 = y + height - 5;
			        	 	x2 = x + width - 5;
			        	 	y2 = y1 ;
			        	 	x1 = x1 - 5;
			        	 	x2 = x2 - 5;
			        	 	if(row != 0 && col != 0)
				        	 {
					        	 g2d.setStroke(boldStk);
						         g2d.drawLine(x1, y1, x2, y2);
						       //now draw the arrows
						         x2 = x1 + 5;
						         y2 = y1 - 5;
						         x3 = x1 + 5;
						         y3 = y1 + 5;
						         g2d.drawLine(x1, y1, x2, y2);
						         g2d.drawLine(x1, y1, x3, y3);
					        	 g2d.setStroke(prevStk);
				        	 }
			        	 	
		        	 }
		        	// if(prevCell.isCellInDiag(currentCell)){
		        	if(prevCellMap.get(Constant.CELL_IN_DIAG) != null) { 	
		        		 	x1 = x + 10;
			        	 	y1 = y + 5;
			        	 	x2 = x + width - 5;
			        	 	y2 = y + height - 10;
			        	 	x1 = x1 - 5;
			        	 	x2 = x2 - 5;
			        	 	if(row != 0 && col != 0)
				        	 {
					        	 g2d.setStroke(boldStk);
						         g2d.drawLine(x1, y1, x2, y2);
						       //now draw the arrows
						         x2 = x1 ;
						         y2 = y1 + 5;
						         x3 = x1 + 5;
						         y3 = y1;
						         g2d.drawLine(x1, y1, x2, y2);
						         g2d.drawLine(x1, y1, x3, y3);
					        	 g2d.setStroke(prevStk);
				        	 }
			        	 	    	 	
			         }
		        	 
		         }
		        
		         
		         //draw the score
		         score = String.valueOf( currentCell.getScore() );
		         x1 = x + (width/2);
		         y1 = y + (height/2);
		         g2d.drawString(score, x1, y1);
		         
		         x += 50;
		         
		         if(col != 0){
		        	 if(row == 0){
			    		 seq = String.valueOf( strSeq2.charAt(col-1) );
			    		 x1 = x - (width/2);
				         y1 = y - (height/4) ;
				         g2d.drawString(seq, x1, y1); 
		        	 }
		         }
		         	         
		      }
		      if (row == 0)
		        area.width += x;
			  
		      x = 30;
			  y += 50;
			 
		      if(row != 0){		    	  
		    		 seq = String.valueOf( strSeq1.charAt(row-1) );
		    		 x1 = x - (width/2);
			         y1 = y - (height/2);
			         g2d.drawString(seq, x1, y1);	    	  	    	  
		      }
		      
		      
		   }
	   
	   area.height = y;
	}

	public LCSCell[][] getLcsMatrix() {
		return lcsMatrix;
	}

	public void setLcsMatrix(LCSCell[][] lcsMatrix) {
		this.lcsMatrix = lcsMatrix;
	}

	public String getStrSeq1() {
		return strSeq1;
	}

	public void setStrSeq1(String strSeq1) {
		this.strSeq1 = strSeq1;
	}

	public String getStrSeq2() {
		return strSeq2;
	}

	public void setStrSeq2(String strSeq2) {
		this.strSeq2 = strSeq2;
	}

	public void scroller(){
		if (area == null) return;
		area.width += 50;
		area.height += 50;
		this.setPreferredSize(area);
		this.revalidate();
		this.repaint();
		
	}

}

package ogirri.dp;

import java.util.*;

import javax.swing.JOptionPane;

public class DynProgBkup {

	private static Cell cellTable[][];
	private static int nCols;
	private static int nRows;
	private static int weights[][];
	private static boolean isInitialized;
	private static Scanner sc = null;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		nCols = Integer.parseInt(
			JOptionPane.showInputDialog("Enter the number of columns")
			);

		nRows = Integer.parseInt(
				JOptionPane.showInputDialog("Enter the number of rows")
		);
		cellTable = new Cell[nRows][nCols];
		weights = new int[nRows][nCols];
		
		
		//now compute the other weights
		initialize();
		fillCellTable();
		System.out.println("The longest path through the matrix as " +
				"obtained by Dynamic Programming is...");
		System.out.println(doTraceback());
		
	}
	
	public static void initialize() {
		//get the weights that we need for the whole table 
		String sWeight = "";
		   for (int row = 0; row < cellTable.length; row++) {
		      for (int col = 0; col < cellTable[row].length; col++) {

		    	  sWeight = JOptionPane.showInputDialog(
		    			  "Enter the weight for Row " + row
							+ " and Column " + col);
					weights[row][col] = Integer.parseInt(sWeight);
		         cellTable[row][col] = new Cell(row, col);
		      }
		   }
		   
		   initializeScores();
		   isInitialized = true;
	}
	
	public static void initializeScores(){
		//start by setting the first cell score to 0
		cellTable[0][0].setScore(0);
		int score = 0;
		
		//start by getting the weights for each cell
		//at column 0 and row row 
		for(int row = 1; row < nRows; row++){
				score = cellTable[row-1][0].getScore() + weights[row-1][0];	
				cellTable[row][0].setScore(score);
		}
		
		//start by getting the weights for each cell
		//at column col and row 0 
		for(int col = 1; col < nCols; col++){
				score = cellTable[0][col-1].getScore() + weights[0][col-1];	
				cellTable[0][col-1].setScore(score);
		}
		
	}
	

	public static void fillCellTable() {
		int aboveWt, leftWt, diagWt = 0;
	   for (int row = 1; row < cellTable.length; row++) {
	      for (int col = 1; col < cellTable[row].length; col++) {
	         Cell currentCell = cellTable[row][col];
	         Cell cellAbove = cellTable[row - 1][col];
	         Cell cellToLeft = cellTable[row][col - 1];
	         Cell cellInDiag = cellTable[row - 1][col - 1];
	         aboveWt = weights[row-1][col];
	         leftWt = weights[row][col-1];
	         diagWt = weights[row-1][col-1];

	         fillCell(currentCell, cellAbove, cellToLeft, 
	        		 aboveWt, leftWt);
	      }
	   }
	}

	
	public static void fillCell(Cell currentCell, Cell cellAbove, Cell cellToLeft,
		      Cell cellInDiag, int aboveWt, int leftWt,
		      int diagWt) {
		   int aboveScore = cellAbove.getScore() + aboveWt;
		   int leftScore = cellToLeft.getScore() + leftWt;
		   int diagScore = cellInDiag.getScore() + diagWt;
		   
		   int cellScore = 0;
		   Cell cellPointer;
		   if (diagScore >= aboveScore) {
		      if (diagScore >= leftScore) {
		         // matchScore >= aboveScore and matchScore >= leftScore
		         cellScore = diagScore;
		         cellPointer = cellInDiag;
		      } else {
		         // leftScore > matchScore >= aboveScore
		         cellScore = leftScore;
		         cellPointer = cellToLeft;
		      }
		   } else {
		      if (aboveScore >= leftScore) {
		         // aboveScore > matchScore and aboveScore >= leftScore
		         cellScore = aboveScore;
		         cellPointer = cellAbove;
		      } else {
		         // leftScore > aboveScore > matchScore
		         cellScore = leftScore;
		         cellPointer = cellToLeft;
		      }
		   }
		   currentCell.setScore(cellScore);
		   currentCell.setPrevCell(cellPointer);
	}
	
	
	public static void fillCell(Cell currentCell, Cell cellAbove, 
			Cell cellToLeft, int aboveWt, int leftWt) {
		   int aboveScore = cellAbove.getScore() + aboveWt;
		   int leftScore = cellToLeft.getScore() + leftWt;
		  
		   int cellScore = 0;
		   Cell cellPointer;
		   if (leftScore >= aboveScore) {
		      if (leftScore > aboveScore) {
		         cellScore = leftScore;
		         cellPointer = cellToLeft;
		      } else {
		    	  //ideally if they are the same the two 
		    	  //should be set as pointers
		         // leftScore == aboveScore
		         cellScore = leftScore;
		         cellPointer = cellToLeft;
		      }
		   } else {//aboveScore > leftScore
		      if (aboveScore >= leftScore) {
		         // aboveScore >= leftScore
		         cellScore = aboveScore;
		         cellPointer = cellAbove;
		      } else {
		         // leftScore > aboveScore
		         cellScore = leftScore;
		         cellPointer = cellToLeft;
		      }
		   }
		   currentCell.setScore(cellScore);
		   currentCell.setPrevCell(cellPointer);
	}
	

	public static String doTraceback() {
		   StringBuffer buf = new StringBuffer();
		   Cell currentCell = cellTable[cellTable.length - 1][cellTable[0].length - 1];
		   Cell prevCell;
		   //while (currentCell != null && prevCell != null && currentCell.getScore() > 0) {
		   while(currentCell.getPrevCell() != null){
			  prevCell = currentCell.getPrevCell();

		         buf.insert(0, "[" + currentCell.getRow() + "," + currentCell.getCol() + "]");

		      currentCell = prevCell;
		   }

		   return buf.toString();
	}
	
}

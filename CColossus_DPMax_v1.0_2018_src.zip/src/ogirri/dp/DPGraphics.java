/**
 * 
 */
package ogirri.dp;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EtchedBorder;

/**
 * @author Desmond Ogirri
 *
 */
public class DPGraphics extends JPanel 
	implements ActionListener, MouseListener{

	private BorderLayout bdL = new BorderLayout();
	private LCSDrawPanel lcsPanel;
	
	private Graphics2D g2d;
	private Graphics gr;
	
	private LCSCell[][] lcsMatrix;
	private String strSeq1;
	private String strSeq2;
	
	private Cell[][] matrix;
	private int[][] row_weights;
	private int[][] col_weights;
	
	private int state; 
	private Dimension area; 
	private JScrollPane scroller;
	private Dimension area2;
	private WeightsDrawPanel wtsPanel;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5652835700572911207L;

	
	public DPGraphics(){
		super();
		setLayout(bdL);
		lcsPanel = new LCSDrawPanel();
		scroller = new JScrollPane(lcsPanel);
		area = new Dimension(3000, 3000);
		area2 = Toolkit.getDefaultToolkit().getScreenSize();

		add(scroller, BorderLayout.CENTER);
		this.setPreferredSize(area);
		this.setSize(area);
		this.setOpaque(true);
		scroller.setEnabled(true);
		this.setBorder(BorderFactory.createBevelBorder(20));
		state = Constant.DP_TYPE_LCS;
	}
	
	public DPGraphics(LCSCell[][] matrix, String strSeq1, String strSeq2){
		super();
		setLayout(bdL);
		lcsPanel = new LCSDrawPanel(matrix, strSeq1, strSeq2);
		scroller = new JScrollPane(lcsPanel);
		area = new Dimension(3000, 3000);
		area = Toolkit.getDefaultToolkit().getScreenSize();
		add(scroller, BorderLayout.CENTER);
		add(lcsPanel, BorderLayout.SOUTH);
		this.lcsMatrix = matrix;
		this.strSeq1 = strSeq1;
		this.strSeq2 = strSeq2;
		this.setOpaque(true);
		scroller.setViewportView(lcsPanel);
		this.setBorder(BorderFactory.createBevelBorder(20));
        scroller.setVerticalScrollBarPolicy(
        		ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroller.setHorizontalScrollBarPolicy(
        		ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        
        state = Constant.DP_TYPE_LCS;
	}
	
	public DPGraphics(Cell[][] matrix, int[][] row_wts, int [][] col_wts){
		super();
		setLayout(bdL);
		this.matrix = matrix;
		this.row_weights = row_wts;
		this.col_weights = col_wts;
		wtsPanel = new WeightsDrawPanel(matrix, row_weights, col_weights);
		scroller = new JScrollPane(wtsPanel);
		area = new Dimension(3000, 3000);
		this.setSize(area);
		add(scroller, BorderLayout.CENTER);
		this.setMinimumSize(area);
		scroller.setMinimumSize(area);
		this.setBorder(BorderFactory.createBevelBorder(20));
        scroller.setVerticalScrollBarPolicy(
        		ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroller.setHorizontalScrollBarPolicy(
        		ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        state = Constant.DP_TYPE_WEIGHTS;
        this.setOpaque(true);
	}

	public void drawMatrix(int[][] matrix){
		
	}
	
	
	public void drawMatrix(Integer[][] matrix){
		
	}
	
	
	public void drawMatrix(double[][] matrix){
		
	}
	
	
	public void drawMatrix(Double[][] matrix){
		
	}
	
	
	public void drawMatrix(Cell[][] matrix, int[][] row_weights, int[][] col_weights){
		
	}
	
	
	
	public LCSCell[][] getLcsMatrix() {
		return lcsMatrix;
	}

	public void setLcsMatrix(LCSCell[][] lcsMatrix) {
		this.lcsMatrix = lcsMatrix;
		lcsPanel.setLcsMatrix(lcsMatrix);
	}

	public String getStrSeq1() {
		return strSeq1;
	}

	public void setStrSeq1(String strSeq1) {
		this.strSeq1 = strSeq1;
		lcsPanel.setStrSeq1(strSeq1);
	}

	public String getStrSeq2() {
		return strSeq2;
	}

	public void setStrSeq2(String strSeq2) {
		this.strSeq2 = strSeq2;
		lcsPanel.setStrSeq2(strSeq2);
	}
	
	public void scroller(){
		area = new Dimension();
		area.width = 4000;
		area.height = 4000;
		lcsPanel.setPreferredSize(area);
		lcsPanel.revalidate();
		this.revalidate();
		scroller.revalidate();
		this.repaint();
		lcsPanel.repaint();
		
	}

	public LCSDrawPanel getLcsPanel() {
		return lcsPanel;
	}

	public void setLcsPanel(LCSDrawPanel lcsPanel) {
		this.lcsPanel = lcsPanel;
	}

	public Cell[][] getMatrix() {
		return matrix;
	}

	public void setMatrix(Cell[][] matrix) {
		this.matrix = matrix;
		this.wtsPanel.setMatrix(matrix);
	}

	public int[][] getRow_weights() {
		return row_weights;
	}

	public void setRow_weights(int[][] row_weights) {
		this.row_weights = row_weights;
		this.wtsPanel.setRow_weights(row_weights);
	}

	public int[][] getCol_weights() {
		return col_weights;
	}

	public void setCol_weights(int[][] col_weights) {
		this.col_weights = col_weights;
		this.wtsPanel.setCol_weights(col_weights);
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public JScrollPane getScroller() {
		return scroller;
	}

	public void setScroller(JScrollPane scroller) {
		this.scroller = scroller;
	}

	public WeightsDrawPanel getWtsPanel() {
		return wtsPanel;
	}

	public void setWtsPanel(WeightsDrawPanel wtsPanel) {
		this.wtsPanel = wtsPanel;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		scroller();		
	}


	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		scroller();
	}


	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		scroller();
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
}

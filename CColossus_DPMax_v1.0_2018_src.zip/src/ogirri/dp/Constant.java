/**
 * 
 */
package ogirri.dp;

/**
 * @author Desmond Ogirri
 *
 */
public class Constant {

	
	public static final int DP_TYPE_LCS = 0;
	public static final int DP_TYPE_WEIGHTS = 1;
	public static final int DP_TYPE_DOUBLE = 2;
	public static final int DP_TYPE_INTEGER = 3;
	public static final int DP_TYPE_DBL_PRIM = 4;
	public static final int DP_TYPE_INT_PRIM = 5;
	public static final int DP_TYPE_CUSTOM = 6;
	
	
	public static final String CELL_IN_DIAG = "CELL_IN_DIAG";
	public static final String CELL_ABOVE = "CELL_ABOVE";
	public static final String CELL_TO_LEFT = "CELL_TO_LEFT";
	
	
	public static final String DP_ALGO_WEIGHTS = "Weights";
	public static final String DP_ALGO_LCS = "Longest Common Subsequence";
	public static final String DP_ALGO_LSA = "Local Sequence Alignment";
	public static final String DP_ALGO_GSA = "Global Sequence Alignment";
	public static final String DP_ALGO_MULTI_DIM = "Multi Dimensional";
	public static final String DP_ALGO_SA_GAPS = "Sequence Alignment with Gaps";
	public static final String DP_ALGO_ROCKS = "Rocks";
	public static final String DP_ALGO_MSA = "Multiple Sequence Alignment";
	public static final String DP_ALGO_CUSTOM = "Custom";
	
}

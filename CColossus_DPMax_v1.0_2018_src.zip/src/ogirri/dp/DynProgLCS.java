package ogirri.dp;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;


public class DynProgLCS implements ActionListener{

	private static LCSCell matrix[][];
	private static int nCols;
	private static int nRows;
	
	private static int score;
	
	private static String strSeq1 = "";
	private static String strSeq2 = "";
	private static int editDist;
	private static int lcsLen;
	private static int alignEdDist;
	
	//private static JPanel inPanel;
	private static JFrame inFrame;
	private static JTextArea txtArea1;
	private static JTextArea txtArea2;
	private static JTextArea txtArea3;
	private static JTextField txtEdit;
	
	private static DPGraphics dpg;
	
	private static JButton btnOK;
	private static JButton btnCancel;
	
	private static StringBuffer buf1 = new StringBuffer();
	private static StringBuffer buf2 = new StringBuffer();
	
	private static JTabbedPane inputPane;
	
	private Font viewFont = new Font("Verdana", Font.BOLD, 12);
	private static Font bigFont = new Font("Verdana", Font.BOLD, 12);
	private Font smallFont = new Font("Verdana", Font.PLAIN, 10);
	
	private static String title = "Longest Common Subsequence using Dynamic Programming";
	private static String copyRight = title + "\n" + 
		"Copyright (c) 2009 Desmond Ogirri. All Rights Reserved.";
	private static String mesg = 
		"This program is designed to perform Longest Common Subsequence (LCS) \n" +
		"given 2 sequence strings S1 and S2 and the preferred edit distance that \nshould be between them.\n";

	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		buildGUI();
	
	}
	
	
	public static JTabbedPane getInputPane() {
		return inputPane;
	}

	

	public static String getTitle() {
		return title;
	}


	public static void setTitle(String title) {
		DynProgLCS.title = title;
	}


	public static void buildGUI(){
		
        inputPane = new JTabbedPane();
        //JTabbedPane outputPane = new JTabbedPane();
        
        JPanel inputPanel = new JPanel();
        JPanel outputPanel = new JPanel();

        inputPanel.setLayout(new BorderLayout());
        outputPanel.setLayout(new BorderLayout());
        
        outputPanel.setOpaque(true);
        
        // create the gui components -- Jtextareas and Jlabels
        JLabel jl1 = new JLabel("Enter First Sequence (S1):");
        jl1.setForeground(Color.black);
        jl1.setFont(bigFont);
        
        Box topPanel = new Box( BoxLayout.Y_AXIS );
        JPanel panel1 = new JPanel( new BorderLayout() );
        txtArea1 = new JTextArea(10, 20);
        txtArea1.setLineWrap(true);
        txtArea1.setWrapStyleWord(true);
        txtArea1.setEditable(true);
        txtArea1.setBackground(Color.white);
        //txtArea1.setFont(new Font("Courier", Font.BOLD, 12));
        txtArea1.setFont(bigFont);
        
        panel1.add(jl1, BorderLayout.NORTH);
        panel1.add(new JScrollPane(txtArea1), BorderLayout.CENTER);
        panel1.setAlignmentX( Component.LEFT_ALIGNMENT );
        topPanel.add( Box.createVerticalStrut(15) );
        topPanel.add( panel1 );

        inputPanel.add( topPanel, BorderLayout.NORTH );
        //c.add( topPanel, BorderLayout.NORTH );
        
        Box bottomPanel  =  new Box( BoxLayout.Y_AXIS );
        JPanel panel2 = new JPanel( new BorderLayout() );

        JLabel jl2 = new JLabel("Enter Second Sequence (S2):");
        jl2.setForeground(Color.black);
        jl2.setFont(bigFont);
        
        txtArea2 = new JTextArea(10, 20);
        txtArea2.setLineWrap(true);
        txtArea2.setWrapStyleWord(true);
        txtArea2.setEditable(true);
        txtArea2.setBackground(Color.white);
        //txtArea2.setFont(new Font("Courier", Font.BOLD, 12));
        txtArea2.setFont(bigFont);
        
        bottomPanel.add( Box.createVerticalStrut(15) );
        panel2.add(jl2, BorderLayout.NORTH);
        panel2.add(new JScrollPane(txtArea2), BorderLayout.CENTER);
        panel2.setAlignmentX( Component.LEFT_ALIGNMENT );
        bottomPanel.add( panel2 );

        JLabel jl3 = new JLabel("Enter the edit distance:");
        jl3.setForeground(Color.black);
        jl3.setFont(bigFont);
        
        JPanel panel3 = new JPanel( new BorderLayout() );
        txtEdit = new JTextField("2", 30);
        txtEdit.setFont(bigFont);
        
        bottomPanel.add( Box.createVerticalStrut(15) );
        panel3.add(jl3, BorderLayout.NORTH);
        panel3.add(txtEdit, BorderLayout.CENTER);
        panel3.add(Box.createVerticalStrut(35), BorderLayout.SOUTH);
        panel3.setAlignmentX( Component.LEFT_ALIGNMENT );
        bottomPanel.add( panel3 );
        
        //c.add( bottomPanel, BorderLayout.CENTER );
        inputPanel.add( bottomPanel, BorderLayout.CENTER );
        
        Box btnPanel = new Box( BoxLayout.X_AXIS );
        btnOK = new JButton("OK");
        btnOK.setFont(bigFont);
        btnOK.setBackground( new Color(124, 184, 201) );
        
        btnCancel = new JButton("Cancel");
        btnCancel.setFont(bigFont);
        btnCancel.setBackground( new Color(124, 184, 201) );
        
        btnPanel.add(btnOK);
        btnPanel.add( Box.createHorizontalGlue() );
        btnPanel.add(btnCancel);
        
        //c.add(btnPanel, BorderLayout.SOUTH);
        inputPanel.add(btnPanel, BorderLayout.SOUTH);
        
        btnOK.addActionListener(new DynProgLCS());
        btnCancel.addActionListener(new DynProgLCS());
        
        
        //build output panel
        //txtArea3 = new JTextArea(copyRight);
        txtArea3 = new JTextArea(10, 24);
        txtArea3.setLineWrap(true);
        txtArea3.setWrapStyleWord(true);
        txtArea3.setEditable(false);
        txtArea3.setBackground(Color.white);
        //txtArea3.setFont(new Font("Courier", Font.BOLD, 12));
        txtArea3.setFont(new Font("Verdana", Font.BOLD, 12));
        txtArea3.setText(copyRight);
        outputPanel.add(new JScrollPane(txtArea3));
        
        //now add the graphics drawer
        //dpg = new DPGraphics(matrix, strSeq1, strSeq2);
        dpg = new DPGraphics();
        dpg.setOpaque(true);
        
        inputPane.add(inputPanel);
        inputPane.add(outputPanel);
        
        
        inputPane.add(dpg);
        //dpg.setSize(700, 700);
        inputPane.setTitleAt(0, "Input");
        inputPane.setTitleAt(1, "Output");
        inputPane.setTitleAt(2, "Graphics");
        
        inputPane.setFont(bigFont);

      }
	
	public static void doLCS(){
		nRows = strSeq1.trim().length() + 1;
		nCols = strSeq2.trim().length() + 1;

		int seq1Len = strSeq1.trim().length();
		int seq2Len = strSeq2.trim().length();

		lcsLen = getLCSLength(nRows, nCols, editDist);
		matrix = new LCSCell[nRows][nCols];
		
		//now compute the scores and all else
		initialize();
		fillMatrix();

		String output1 = "The LCS through the matrix as obtained by " +
				"Dynamic Programming is...\n";
		String lcs = doTraceback();
		String seq1 = "Sequence 1 = " + strSeq1 + " [" + seq1Len + "-mer]";
		String seq2 = "Sequence 2 = " + strSeq2 + " [" + seq2Len + "-mer]";
		String ruler = "\n=============================================\n";
		String align = "The alignment is:\n" + buf1 + 
				"\n" + buf2 + "\n" + 
				"The alignment edit distance is " + alignEdDist + "\n";

		if (lcs.length() <= lcsLen){ 
			lcsLen = lcs.length();	
		}else{
			lcs = lcs.substring(0, lcsLen);
		}
		String output2 = "\nThe score of the LCS is " + score + 
				"\nThe length of the LCS is " + lcsLen;
		txtArea3.append(ruler +
				seq1 + "\n" + seq2 + "\n" + align + output1 + lcs + output2);

		dpg.setLcsMatrix(matrix);
		dpg.setStrSeq1(strSeq1);
		dpg.setStrSeq2(strSeq2);
		
	} 
	
	public static int getLCSLength(int seq1Len, int seq2Len, int editDist){
		int lcsLen = ( (seq1Len + seq2Len - editDist) / 2 );
		return lcsLen;
	}
	
	public static void initialize() {
	//get the weights that we need for the whole table 
	 for (int row = 0; row < nRows; row++) {
	      for (int col = 0; col < nCols; col++) 
	      {
	         matrix[row][col] = new LCSCell(row, col);
	      }
	   }	   
		   initializeScores();
	}
	
	public static void initializeScores(){
		int score = 0;
	
		//set the scores for each cell
		//at first column ie column 0 and row row 
		//at the first column the prev cell is the cell above
		//except for the first cell at 0, 0
		for(int row = 0; row < nRows; row++){	
				matrix[row][0].setScore(score);
				if(row != 0){
					LCSCell prevCell = matrix[row-1][0];
					char seq1Char = strSeq1.charAt(row-1);
					matrix[row][0].setPrevCell(prevCell);
					matrix[row][0].setSeq1Char(seq1Char);
				}
		}
		
		//then set the scores for each cell
		//at first row ie column col and row 0 
		//at the first row the prev cell is the cell to the
		//left except for the first cell at 0, 0
		for(int col = 0; col < nCols; col++){	
				matrix[0][col].setScore(score);
				if(col != 0){
					LCSCell prevCell = matrix[0][col-1];
					char seq2Char = strSeq2.charAt(col-1);
					matrix[0][col].setPrevCell(prevCell);
					matrix[0][col].setSeq2Char(seq2Char);
				}
		}
		
	}
	
	
	//The rule for filling the LCS matrix is:
	//1. if Vi == Wj (meaning we have a match between the 2 sequences)
	//the score for the cell is max of either the diagonal OR the left OR 
	//the right cells
	//2. otherwise (we dont have a match) and then
	// the score of the current cell is the max of either the left OR right cells
	public static void fillMatrix() {
	   for (int row = 1; row < nRows; row++) {
	      for (int col = 1; col < nCols; col++) {
	         LCSCell currentCell = matrix[row][col];
	         LCSCell cellAbove = matrix[row - 1][col];
	         LCSCell cellToLeft = matrix[row][col - 1];
	         LCSCell cellInDiag = matrix[row - 1][col - 1];
	         if(strSeq1.charAt(row-1) != strSeq2.charAt(col-1)){
	        	 fillCell(currentCell, cellAbove, cellToLeft);
	         }else{

	        	 fillCell(currentCell, cellAbove, cellToLeft, cellInDiag);
	         }
	         currentCell.setSeq1Char(strSeq1.charAt(row-1));
	         currentCell.setSeq2Char(strSeq2.charAt(col-1));

	      }
	   }
	}
	
	
	public static void fillCell(LCSCell currentCell, LCSCell cellAbove, 
			LCSCell cellToLeft) {
		   int aboveScore = cellAbove.getScore();
		   int leftScore = cellToLeft.getScore();
		  
		   int cellScore = 0;
		   LCSCell prevCell;
		   Map<String, LCSCell> pcMap = new HashMap<String, LCSCell>();
		   if (leftScore >= aboveScore) {
		      if (leftScore > aboveScore) {
		         cellScore = leftScore;
		         prevCell = cellToLeft;
		         pcMap.put(Constant.CELL_TO_LEFT, cellToLeft);
		      } else {
		    	  //ideally if they are the same the two 
		    	  //should both be set as pointers
		         // leftScore == aboveScore
		         cellScore = aboveScore;
		         prevCell = cellAbove;
		         pcMap.put(Constant.CELL_TO_LEFT, cellToLeft);
		         pcMap.put(Constant.CELL_ABOVE, cellAbove);
		      }
		   } else {//aboveScore > leftScore
		      
		         cellScore = aboveScore;
		         prevCell = cellAbove;
		         pcMap.put(Constant.CELL_ABOVE, cellAbove);
		   }
		   currentCell.setScore(cellScore);
		   currentCell.setPrevCell(prevCell);
		   currentCell.setPrevCellMap(pcMap);
	}
	
	public static void fillCell(LCSCell currentCell, LCSCell cellAbove, 
		   LCSCell cellToLeft, LCSCell cellInDiag) {
		   int aboveScore = cellAbove.getScore();
		   int leftScore = cellToLeft.getScore();
		   int diagScore = cellInDiag.getScore() + 1;
		  
		   int cellScore = 0;
		   LCSCell prevCell;
		   LCSCell cellAbove2 = null;
		   LCSCell cellToLeft2 = null;
		   LCSCell cellInDiag2 = null;
		   Map<String, LCSCell> pcMap = new HashMap<String, LCSCell>();
		   //As in the fillCell method with only 2 possible
		   //previous cells above, there should be a list/array of
		   //previous cells. so that every cell can have all possible
		   //previous cells set. this will enable the matrix to produce
		   //all possible paths/LCS candidates
		   if (diagScore >= aboveScore) {
			   if(diagScore > aboveScore){
			      if (diagScore >= leftScore) {
			    	  if (diagScore > leftScore) {
			         // diagScore > aboveScore and diagScore > leftScore
			         cellScore = diagScore;
			         prevCell = cellInDiag;
			         cellInDiag2 = cellInDiag;
			         pcMap.put(Constant.CELL_IN_DIAG, cellInDiag);
			    	  }else {
					         // diagScore > aboveScore and diagScore == leftScore
					         cellScore = diagScore;
					         prevCell = cellInDiag;
					         cellInDiag2 = cellInDiag;
					         pcMap.put(Constant.CELL_IN_DIAG, cellInDiag);
					         pcMap.put(Constant.CELL_TO_LEFT, cellToLeft);
			    	  }
			      } else {
			         // leftScore > diagScore > aboveScore
			         cellScore = leftScore;
			         prevCell = cellToLeft;
			         cellToLeft2 = cellToLeft;
			         pcMap.put(Constant.CELL_TO_LEFT, cellToLeft);
			      }
			   }else{
				   //diagScore == aboveScore
				   //default is diagonal
				   	 cellScore = diagScore;
			         prevCell = cellInDiag;
			         cellInDiag2 = cellInDiag;
			         pcMap.put(Constant.CELL_IN_DIAG, cellInDiag);
			         pcMap.put(Constant.CELL_ABOVE, cellAbove);
			   }
			} else {
				  //aboveScore > diagScore
			      if (aboveScore >= leftScore) {
			    	  if (aboveScore > leftScore) {
				         // aboveScore > diagScore and aboveScore > leftScore
				         cellScore = aboveScore;
				         prevCell = cellAbove;
				         cellAbove2 = cellAbove;
				         pcMap.put(Constant.CELL_ABOVE, cellAbove);
			    	  }else{
			    		// aboveScore > diagScore and aboveScore == leftScore
			    		  //default prev cell is above cell
			    		 cellScore = aboveScore;
				         prevCell = cellAbove;
				         cellAbove2 = cellAbove;
				         cellToLeft2 =  cellToLeft;
				         pcMap.put(Constant.CELL_ABOVE, cellAbove); 
				         pcMap.put(Constant.CELL_TO_LEFT, cellToLeft); 
			    	  }
			      } else {
			         // leftScore > aboveScore > diagScore
			         cellScore = leftScore;
			         prevCell = cellToLeft;
			         cellToLeft2 = cellToLeft;
			         pcMap.put(Constant.CELL_TO_LEFT, cellToLeft);
			      }
			}
		   currentCell.setScore(cellScore);
		   currentCell.setPrevCell(prevCell);
		   currentCell.setCellAbove(cellAbove2);
		   currentCell.setCellInDiag(cellInDiag2);
		   currentCell.setCellToLeft(cellToLeft2);
		   currentCell.setPrevCellMap(pcMap);
	}
	
	
	
		public static String doTraceback() {
		   StringBuffer lcs = new StringBuffer();
		   StringBuffer lcs2 = new StringBuffer();
		   buf1 = new StringBuffer();
		   buf2 = new StringBuffer();
		   alignEdDist = 0;
		   //printMatrix(matrix);
		   LCSCell currentCell = matrix[nRows - 1][nCols - 1];
		   LCSCell prevCell;
		   score = currentCell.getScore();

		   while(currentCell.getPrevCell() != null){
			  prevCell = currentCell.getPrevCell();

			  if (prevCell.isCellAbove(currentCell)) {
				  buf2.insert(0, currentCell.getSeq2Char());
		       } else {
		    	  buf2.insert(0, '-');
		          alignEdDist++;
		       }
		      if (prevCell.isCellToLeft(currentCell)) {
		    	  buf1.insert(0, currentCell.getSeq1Char());
		       } else {
		    	  buf1.insert(0, '-'); 
		    	  alignEdDist++;
		       }
		      
		      if (
		    	currentCell.charsMatch() && prevCell.isCellInDiag(currentCell)
		         ) 
		      {
		          lcs2.insert(0, currentCell.getSeq1Char());
		       }
		      
		      currentCell = prevCell;
		     
		   }
		   for(int i = 0; i < buf1.length(); i++){
		    	  if(buf1.charAt(i) == buf2.charAt(i)){
		    		  lcs.append(buf1.charAt(i));
		    	  }
		   }
		   return lcs2.toString();
	}
	
	
	public static String doTraceback2() {
		   StringBuffer lcs = new StringBuffer();
		   buf1 = new StringBuffer();
		   buf2 = new StringBuffer();
		   LCSCell currentCell = matrix[nRows - 1][nCols - 1];
		   LCSCell prevCell;
		   score = currentCell.getScore();
		   while(currentCell.getPrevCell() != null){ 
			  prevCell = currentCell.getPrevCell();
			  if (prevCell.isCellAbove(currentCell)) {
				  buf1.insert(0, currentCell.getSeq1Char());
		       } else {
		          buf1.insert(0, '-');
		       }
		      if (prevCell.isCellToLeft(currentCell)) {
		    	  buf2.insert(0, currentCell.getSeq2Char());
		       } else {
		          buf2.insert(0, '-');
		       }		      
		      currentCell = prevCell;
		   }
		   
		   for(int i = 0; i < buf1.length(); i++){
		    	  if(buf1.charAt(i) == buf2.charAt(i)){
		    		  lcs.append(buf1.charAt(i));
		    	  }
		   }
		   
		   return lcs.toString();
	}
	
	
	
	class LCSListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent evt) {
			// TODO Auto-generated method stub
			 Component comp = (Component)evt.getSource();
			 if(comp instanceof JButton){
				   //JButton btn = (JButton)comp;
			 }
		}
		
	}


	@Override
	public void actionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		 Component comp = (Component)evt.getSource();
		 if(comp instanceof JButton){
			   JButton btn = (JButton)comp;
			   if(btn.getText() == "OK"){
				   strSeq1 = txtArea1.getText();
				   strSeq2 = txtArea2.getText();
				   if ( strSeq1.trim().length() == 0 ||
						   strSeq2.trim().length() == 0 )
					   return;
				   editDist = Integer.parseInt( txtEdit.getText() );
				   doLCS();
			   }else  if(btn.getText() == "Cancel"){
				   System.exit(0);
			   }
		 }
	}
	
	public static void printMatrix(LCSCell[][] matrix){
		 for (int row = 0; row < nRows; row++) {
		      for (int col = 0; col < nCols; col++) {
		         LCSCell currentCell = matrix[row][col];
		         LCSCell prevCell = currentCell.getPrevCell();
		         System.out.println("Current cell is " + currentCell);
		         if(prevCell != null)
		        	 System.out.println("Previous cell is " + prevCell);
		         else
		        	 System.out.println("Previous cell is null"); 
		      }
		 }
	}
	
	
}

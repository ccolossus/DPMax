/**
 * 
 */
package ogirri.dp;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.border.TitledBorder;


/**
 * @author Desmond Ogirri
 *
 */
public class DPMaxController extends JApplet implements ActionListener {

	private ButtonGroup menuBtnGroup;
	private ButtonGroup algoBtnGroup;
	private ButtonGroup gamesBtnGroup;

	private JRadioButton generalRadioBtn;
	private JRadioButton gamesRadioBtn;
	private JRadioButton randomRadioBtn;
	
	private JRadioButton lsaRadioBtn;
	private JRadioButton gsaRadioBtn;
	private JRadioButton multiRadioBtn;
	
	private JRadioButton saGapsRadioBtn;
	private JRadioButton rocksRadioBtn;
	
	private JPanel rightPanel;
	private JPanel lcsPanel; //for LCS
	private JPanel weightsPanel; //for weights
	private JPanel customPanel; //for custom
	
	private JPanel leftPanel;
	private JPanel optionsPanel; //for showing the diff menu
	
	private TitledBorder generalBorder;
	private TitledBorder resultsBorder;
	private TitledBorder menuBorder;
	private TitledBorder algoBorder;
	
	private Font viewFont = new Font("Verdana", Font.BOLD, 12);
	private Font bigFont = new Font("Verdana", Font.BOLD, 12);
	private Font smallFont = new Font("Verdana", Font.PLAIN, 10);
	
	private boolean isStandalone;
	private JPanel menuPanel;
	private String menuTitle = "Algorithm";
	private JRadioButton weightsRadioBtn;
	private ActionListener menuListener;
	private JRadioButton lcsRadioBtn;
	private JRadioButton customRadioBtn;
	private JComponent mainPanel;
	private Object dpType;
	
	private DynProgLCS lcs;
	private DynProgWeights dpWts;
	private JTabbedPane wtsPane;
	private JRadioButton msaRadioBtn;
	
	private static String appTitle = "DPMax 1.0 2018";
	
	private static JTabbedPane lcsPane;
	private static JFrame frame;
	
	 public void setCompFont(JPanel panel){
		    Component[] comps = panel.getComponents();
		    for(int i = 0; i < comps.length; i++){
		      comps[i].setFont(viewFont);
		    }
	}

	  public void setActionListener(JPanel panel, ActionListener listener, String compType){

	    Component[] comps = panel.getComponents();

	    if(compType.equalsIgnoreCase("JRadioButton")){
	        for(int i = 0; i < comps.length; i++){
	          if(comps[i] instanceof JRadioButton)
	           ((JRadioButton)comps[i]).addActionListener(listener);
	       }
	    }
	  }

	  public void buildGUI(){
		    mainPanel = new JPanel();
		    mainPanel.setLayout(new BorderLayout());

		    //build the left panel
		    buildLeftPanel();
		    //build right panel
		    buildRightPanel();
		    mainPanel.add(leftPanel, BorderLayout.WEST);
		    mainPanel.add(rightPanel, BorderLayout.CENTER);
		  }

	  
	  public void buildLeftPanel(){
		    GridBagConstraints c = new GridBagConstraints();
		    leftPanel = new JPanel();
		    leftPanel.setLayout(new GridLayout(2, 1));
		    //build the menu panel
		    buildMenuPanel();
		    buildOptionsPanel();
		    leftPanel.add(menuPanel);
		    leftPanel.setFont(bigFont);
		    //leftPanel.add(algorithmPanel);
		    leftPanel.add(optionsPanel);
		  
	  }
	  
	  public void buildMenuPanel(){
		    menuPanel = new JPanel();
		    menuBorder = new TitledBorder(menuTitle);
		    menuBorder.setTitleFont(bigFont);
		    menuPanel.setBorder(menuBorder);
		    menuPanel.setLayout(new GridLayout(8, 1));
		    menuPanel.setFont(smallFont);
		    
		    menuBtnGroup = new ButtonGroup();
		    //add the radio buttons
		    weightsRadioBtn = new JRadioButton(Constant.DP_ALGO_WEIGHTS);
		    weightsRadioBtn.setSelected(true);
		    weightsRadioBtn.setFont(smallFont);
		    weightsRadioBtn.setActionCommand(Constant.DP_ALGO_WEIGHTS);
		    weightsRadioBtn.addActionListener(this);
		    
		    lcsRadioBtn = new JRadioButton(Constant.DP_ALGO_LCS);
		    lcsRadioBtn.setActionCommand(Constant.DP_ALGO_LCS);
		    lcsRadioBtn.setFont(smallFont);
		    lcsRadioBtn.addActionListener(this);
		    
		    customRadioBtn = new JRadioButton(Constant.DP_ALGO_MULTI_DIM);
		    customRadioBtn.setActionCommand(Constant.DP_ALGO_MULTI_DIM);
		    customRadioBtn.setFont(smallFont);
		    customRadioBtn.addActionListener(this);

		    lsaRadioBtn = new JRadioButton(Constant.DP_ALGO_LSA);
		    lsaRadioBtn.setActionCommand(Constant.DP_ALGO_LSA);
		    lsaRadioBtn.setFont(smallFont);
		    lsaRadioBtn.addActionListener(this);
		    
		    gsaRadioBtn = new JRadioButton(Constant.DP_ALGO_GSA);
		    gsaRadioBtn.setActionCommand(Constant.DP_ALGO_GSA);
		    gsaRadioBtn.setFont(smallFont);
		    gsaRadioBtn.addActionListener(this);
		    
		    rocksRadioBtn = new JRadioButton(Constant.DP_ALGO_ROCKS);
		    rocksRadioBtn.setActionCommand(Constant.DP_ALGO_ROCKS);
		    rocksRadioBtn.setFont(smallFont);
		    rocksRadioBtn.addActionListener(this);
		    
		    saGapsRadioBtn = new JRadioButton(Constant.DP_ALGO_SA_GAPS);
		    saGapsRadioBtn.setActionCommand(Constant.DP_ALGO_SA_GAPS);
		    saGapsRadioBtn.setFont(smallFont);
		    saGapsRadioBtn.addActionListener(this);
		    
		    msaRadioBtn = new JRadioButton(Constant.DP_ALGO_MSA);
		    msaRadioBtn.setActionCommand(Constant.DP_ALGO_GSA);
		    msaRadioBtn.setFont(smallFont);
		    msaRadioBtn.addActionListener(this);
		    
		    menuBtnGroup.add(weightsRadioBtn);
		    menuBtnGroup.add(lcsRadioBtn);
		    menuBtnGroup.add(rocksRadioBtn);
		    menuBtnGroup.add(lsaRadioBtn);
		    menuBtnGroup.add(gsaRadioBtn);
		    menuBtnGroup.add(saGapsRadioBtn);
		    menuBtnGroup.add(msaRadioBtn);
		    menuBtnGroup.add(customRadioBtn);

		    menuPanel.add(weightsRadioBtn);
		    menuPanel.add(lcsRadioBtn);
		    menuPanel.add(rocksRadioBtn);
		    menuPanel.add(lsaRadioBtn);
		    menuPanel.add(gsaRadioBtn);
		    menuPanel.add(saGapsRadioBtn);
		    menuPanel.add(msaRadioBtn);
		    menuPanel.add(customRadioBtn);
		    
		    
		  }
	  
	  public void buildRightPanel(){
		    rightPanel = new JPanel();
		    //rightPanel.setLayout(new GridLayout(1, 1));
		    rightPanel.setLayout(new CardLayout());
		    rightPanel.setOpaque(true);
		    //create the LCS panel
		    buildLCSPanel();

		    //build weights panel
		    buildWeightsPanel();

		    //build and add custom panel
		    buildCustomPanel();
		    
		    rightPanel.add(Constant.DP_ALGO_WEIGHTS, wtsPane);
		    rightPanel.add(Constant.DP_ALGO_LCS, lcsPane);
		    rightPanel.add(Constant.DP_ALGO_ROCKS, customPanel);
		    rightPanel.add(Constant.DP_ALGO_LSA, customPanel);
		    rightPanel.add(Constant.DP_ALGO_GSA, customPanel);
		    rightPanel.add(Constant.DP_ALGO_SA_GAPS, customPanel);
		    rightPanel.add(Constant.DP_ALGO_MSA, customPanel);
		    rightPanel.add(Constant.DP_ALGO_CUSTOM, customPanel);
	  }
	  
	  public void buildWeightsPanel(){
		  dpWts = new DynProgWeights();
		  dpWts.buildGUI();
		  wtsPane = dpWts.getInputPane();
		  wtsPane.setOpaque(true);
	  }
	  
	  
	  public void buildLCSPanel(){
		 lcs = new DynProgLCS();
		 lcs.buildGUI(); 
		 lcsPane = lcs.getInputPane();
		 lcsPane.setOpaque(true);
	  }
	  
	  public void buildCustomPanel(){
		  customPanel = new JPanel();
	  }
	  
	  public void buildOptionsPanel(){
		    optionsPanel = new JPanel();
		    optionsPanel.setLayout(new GridBagLayout());
		    GridBagConstraints c = new GridBagConstraints();

		    c.weightx = 1.0;
		    c.weighty = 1.0;
		    //c.fill = c.BOTH;
		    c.anchor = c.NORTHWEST;
		    c.gridx = 0;
		    c.gridy = 0;
		    c.gridheight = 1;
		    c.gridwidth = 1;

		    c.gridx = 0;
		    c.gridy = 1;
		    c.gridheight = 1;
		    c.gridwidth = 1;

		    c.gridx = 0;
		    c.gridy = 2;
		    c.gridheight = 1;
		    c.gridwidth = 1;
		    optionsPanel.add(Box.createHorizontalGlue(), c);
		  }
	
	  public void buildOptionPanel(){
		    optionsPanel = new JPanel();
		    //algoBorder = new TitledBorder(algoTitle);
		    optionsPanel.setBorder(algoBorder);
		    optionsPanel.setLayout(new GridLayout(4, 1));
		    algoBtnGroup = new ButtonGroup();
		    randomRadioBtn = new JRadioButton("RBS");

		  
	  }
	  
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	 public void actionPerformed(ActionEvent evt){
	      Component comp = (Component)evt.getSource();
	      if(comp instanceof JRadioButton){
	        JRadioButton radio = (JRadioButton)comp;
	        String acmd = evt.getActionCommand();
	        CardLayout layout = ((CardLayout)rightPanel.getLayout());
	        if(acmd == Constant.DP_ALGO_WEIGHTS){
	          layout.first(rightPanel);
	          frame.setTitle(appTitle + " - " + DynProgWeights.getTitle());
	         // if (javaRadioBtn.isSelected())
	         //   javaRadioBtn.setSelected(false);;
	        }else if(acmd == Constant.DP_ALGO_LCS){
	          layout.show(rightPanel, Constant.DP_ALGO_LCS);
	          frame.setTitle(appTitle + " - " + DynProgLCS.getTitle());
	          //javaRadioBtn.setSelected(true);
	        }else if(acmd == Constant.DP_ALGO_ROCKS){
	          layout.show(rightPanel, Constant.DP_ALGO_ROCKS);
	        }else if(acmd == Constant.DP_ALGO_LSA){
	          layout.show(rightPanel, Constant.DP_ALGO_LSA);
	        }else if(acmd == Constant.DP_ALGO_GSA){
	          layout.show(rightPanel, Constant.DP_ALGO_GSA);
	        }else if(acmd == Constant.DP_ALGO_SA_GAPS){
	          layout.show(rightPanel, Constant.DP_ALGO_SA_GAPS);
	        }else if(acmd == Constant.DP_ALGO_MULTI_DIM){
	          layout.show(rightPanel, Constant.DP_ALGO_MULTI_DIM);
	        }
	        else if(acmd == Constant.DP_ALGO_CUSTOM){
	          layout.last(rightPanel);
	        }

	        }
	     }
	
	  //Initialize the applet
	  public void init() {
	    try {
	      dpType = this.getParameter("DP_TYPE", "0");
	    }
	    catch(Exception e) {
	      e.printStackTrace();
	    }
	    try {
	      //lenSequences = this.getParameter("LEN_SEQUENCES", "0");
	    }
	    catch(Exception e) {
	      e.printStackTrace();
	    }




	    try {
	      appInit();
	    }
	    catch(Exception e) {
	      e.printStackTrace();
	    }
	  }
	
	  //Component initialization
	  private void appInit() throws Exception {
		 this.buildGUI();
		 this.setLayout(new BorderLayout());
		 mainPanel.setOpaque(true);
	     add(mainPanel, BorderLayout.CENTER);
	     this.setSize(new Dimension(500,500));
	     //this.setVisible(true);
	  }
	  
	  //Start the applet
	  public void start() {
	  }
	  
	  //Stop the applet
	  public void stop() {
	  }
	  
	  //Destroy the applet
	  public void destroy() {
	  }
	  
	  //Get Applet information
	  public String getAppletInfo() {
	    return "Applet Information";
	  }
	  
	  //Get parameter info
	  public String[][] getParameterInfo() {
	    String[][] pinfo =
	      {
	      {"NUM_SEQUENCES", "String", ""},
	      {"LEN_SEQUENCES", "String", ""},
	      };
	    return pinfo;
	  }



	  private Object getParameter(String string, String string2) {
		// TODO Auto-generated method stub
		return null;
	}

	//Main method
	  public static void main(String[] args) {
	    DPMaxController applet = new DPMaxController();
	    applet.isStandalone = true;
	    frame = new JFrame();
	    applet.init();
	    applet.start();
	    //EXIT_ON_CLOSE == 3
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setTitle(appTitle);
	    frame.setResizable(true);

	    frame.setContentPane(applet);
	   
	    frame.setSize(700, 575);
	    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
	    frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
	    frame.setVisible(true);
	  }

}

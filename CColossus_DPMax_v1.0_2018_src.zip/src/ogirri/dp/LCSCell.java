package ogirri.dp;

import java.util.HashMap;
import java.util.Map;

public class LCSCell {

	private int row;
	private int col;
	private int score;
	private char seq1Char;
	private char seq2Char;
	
	private LCSCell cellAbove;
	private LCSCell cellToLeft;
	private LCSCell cellInDiag;
	private LCSCell prevCell;
	
	private Map<String, LCSCell> prevCellMap 
		= new HashMap<String, LCSCell>();
	
	
	   
	public LCSCell(){
		super();
	}
		
	public LCSCell(int row, int col) {
		super();
		this.row = row;
		this.col = col;
	}
	
	public LCSCell(int row, int col, char s1, char s2) {
		super();
		this.row = row;
		this.col = col;
		this.seq1Char = s1;
		this.seq2Char = s2;
	}
	
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getCol() {
		return col;
	}
	public void setCol(int col) {
		this.col = col;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public LCSCell getPrevCell() {
		return prevCell;
	}
	public void setPrevCell(LCSCell prevCell) {
		this.prevCell = prevCell;
	}

	public char getSeq1Char() {
		return seq1Char;
	}

	public void setSeq1Char(char seq1Char) {
		this.seq1Char = seq1Char;
	}

	public char getSeq2Char() {
		return seq2Char;
	}

	public void setSeq2Char(char seq2Char) {
		this.seq2Char = seq2Char;
	}
	
	
	
	public boolean charsMatch(){
		return this.seq1Char == this.seq2Char;
	}
	
	public boolean isCellAbove(LCSCell that){
		return (that.getCol() - this.getCol() == 1);
	}
	
	public boolean isCellToLeft(LCSCell that){
		return (that.getRow() - this.getRow() == 1);
	}
	
	public boolean isCellInDiag(LCSCell that){
		return (that.getCol() - this.getCol() == 1 &&
				that.getRow() - this.getRow() == 1);
	}
	
	public LCSCell getCellAbove() {
		return cellAbove;
	}

	public void setCellAbove(LCSCell cellAbove) {
		this.cellAbove = cellAbove;
	}

	public LCSCell getCellToLeft() {
		return cellToLeft;
	}

	public void setCellToLeft(LCSCell cellToLeft) {
		this.cellToLeft = cellToLeft;
	}

	public LCSCell getCellInDiag() {
		return cellInDiag;
	}

	public void setCellInDiag(LCSCell cellInDiag) {
		this.cellInDiag = cellInDiag;
	}

	public Map<String, LCSCell> getPrevCellMap() {
		return prevCellMap;
	}

	public void setPrevCellMap(Map<String, LCSCell> prevCellMap) {
		this.prevCellMap = prevCellMap;
	}

	public String toString(){
		String ret = "";
		ret += "[LCSCell Row=" + this.row + " Column= " + this.col + 
			" Seq1 Char=" + this.seq1Char + " Seq2 Char=" + this.seq2Char +
			" score=" + this.score + "]"; 
		return ret;
		
	}
}

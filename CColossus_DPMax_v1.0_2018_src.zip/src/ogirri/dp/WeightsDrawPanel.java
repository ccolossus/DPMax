/**
 * 
 */
package ogirri.dp;

import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * @author Desmond Ogirri
 *
 */
public class WeightsDrawPanel extends JPanel {

	private Dimension area;
	private Graphics gr;
	private Graphics2D g2d;
	private JScrollPane scroller;
	private Dimension area2;
	
	
	private int row_weights[][];
	private int col_weights[][];
	private Cell[][] matrix;
	
	private Font viewFont = new Font("Verdana", Font.BOLD, 12);
	private Font bigFont = new Font("Verdana", Font.BOLD, 12);
	private Font smallFont = new Font("Verdana", Font.PLAIN, 10);
	
	public WeightsDrawPanel(){
		super();
	}
	
	public WeightsDrawPanel(Cell[][] matrix, int[][] row_weights, int[][] col_weights){
		super();
		this.matrix = matrix;
		this.row_weights = row_weights;
		this.col_weights = col_weights;
		setOpaque(true);

	}
	
	public void paintComponent(Graphics gee){
		super.paintComponent(gee);
		gr = gee;
		drawMatrix(matrix, row_weights, col_weights);

		scroller();
	}

	
	public void drawMatrix(Cell[][] matrix, int row_weights[][], 
			int col_weights[][]){
		
		if (matrix == null || row_weights == null || col_weights == null)
			return;
		int x = 30;
		int y = 30;
		int x1 = 0;
		int x2 = 0;
		int y1 = 0;
		int y2 = 0;
		int x3 = 0;
		int y3 = 0;
		int width = 50;
		int height = 50;
		int space = 100;
		int row;
		int col;
		String score;
		Stroke prevStk;
		Stroke boldStk = new BasicStroke(2f);
		String wts = "";
		Map<String, Cell> prevCellMap = null;
		area = new Dimension();
		g2d = (Graphics2D)gr;
		Cell[][] copyMatrix = matrix;
		row = copyMatrix.length;
		col = copyMatrix[0].length;
		int lastScore = copyMatrix[row-1][col-1].getScore();
		String sScr = String.valueOf(lastScore);
		int dim = (sScr.length() * 2) + (g2d.getFontMetrics().getHeight());
		width += dim;
		height += dim;
		space += dim;
	   for (row = 0; row < copyMatrix.length; row++) {
		  
		  // y += 50;
		      for (col = 0; col < copyMatrix[row].length; col++) {
		    	 
		         Cell currentCell = copyMatrix[row][col];
		         Cell prevCell = currentCell.getPrevCell();
		         prevCellMap = currentCell.getPrevCellMap();
		         ///*
		         if(row == 0 && col > 0)
		        	 prevCellMap = null;
		         if(col == 0 && row > 0)
		        	 prevCellMap = null;
		         
		         prevStk = g2d.getStroke();
				 //if the prev cell is null just draw the current cell
		         if (prevCellMap == null  || prevCellMap.isEmpty())
		         {	
		        	 g2d.drawOval(x, y, width, height);
		        	
		        	 if(col < matrix[row].length - 1 && row == 0){
		        	//if(row == 0){  
	        		    x1 = x + width;
		        	 	y1 = y + (height/2);
		        	 	x2 = x + space ;
		        	 	y2 = y1;
		        	 	g2d.setStroke(boldStk);
		        	 	g2d.drawLine(x1, y1, x2, y2);
				      //draw the east-west weights
				        wts = String.valueOf( row_weights[row][col] );
		        	 	x3 = (( x1 + x2 ) / 2 ) - (wts.length()*2);
				        //x3 = x2 - x1 - wts.length();
				        y3 = y1 - 10;
				        
		        	 	g2d.drawString(wts, x3, y3); 
	        	 		//now draw the arrows
				         x1 = x2 - 5;
				         y1 = y2 - 5;
				         x3 = x2 - 5;
				         y3 = y2 + 5;
				         g2d.drawLine(x1, y1, x2, y2);
				         g2d.drawLine(x2, y2, x3, y3);	
		        	 	 g2d.setStroke(prevStk);
		        	}
		        	
		        	//if the row is not 0 draw the north-south line
		        	 	if (row > 0 && col == 0){
			        		 //draw the north-south line
			        	 		x1 = x + (width/2);
				        	 	y1 = y - space + height;
				        	 	x2 = x1;
				        	 	y2 = y1 + space - height;
				        	 	g2d.setStroke(boldStk);
						        g2d.drawLine(x1, y1, x2, y2);
						        //draw the north-south weights
						        //g2d.setStroke(prevStk);
				        	    wts = String.valueOf( col_weights[row-1][col] );
			        	 	    x3 = x1 + 10;
			        	 	    y3 = ( y1 + y2 ) / 2;
			        	 	    g2d.drawString(wts, x3, y3); 
				        	    //draw the north-south arrow head
						        x1 = x2 - 5;
						        y1 = y2 - 5;
						        x3 = x2 + 5;
						        y3 = y2 - 5;
						        g2d.drawLine(x1, y1, x2, y2);
						        g2d.drawLine(x2, y2, x3, y3);
						        g2d.setStroke(prevStk);
				        	    
				        }
		        	 	
				        if(col < matrix[row].length - 1 && row != 0){
		        		    x1 = x + width;
			        	 	y1 = y + (height/2);
			        	 	x2 = x + space ;
			        	 	y2 = y1;
			        	 	g2d.drawLine(x1, y1, x2, y2);
	         			      //draw the east-west weights
					        wts = String.valueOf( row_weights[row][col] );
					        x3 = (( x1 + x2 ) / 2 ) - (wts.length()*2);
					        //x3 = x2 - x1 - wts.length();
					        y3 = y1 - 10;
			        	 	g2d.drawString(wts, x3, y3); 
					       
			        	 	 g2d.setStroke(prevStk);
			        	 	 
			        	}
		        	
		         }
		         else //draw the currentcell and get the direction of the 
		        	 //prevcell so we can draw arrows pointing to it
		        	 //and then draw the score and the weights
		        	 //
		         {
		        	 g2d.drawOval(x, y, width, height);
		        	 
		        	 if(col < matrix[row].length - 1 ){
		        	 //if(col >= 0){
		        	 //now draw the east-west line
		        	    x1 = x + width;
		        	 	y1 = y + (height/2);
		        	 	x2 = x + space ;
		        	 	y2 = y1;
		        	 	g2d.drawLine(x1, y1, x2, y2);
		        	 	//draw the east-west score
		        	 	wts = String.valueOf( row_weights[row][col] );
		        	 	x3 = (( x1 + x2 ) / 2 ) - (wts.length()*2);
		        	 	//x3 = x1 - wts.length();
		        	 	y3 = y1 - 10;
		        	 	g2d.drawString(wts, x3, y3); 
		        	}
	        	 	//if the row is not 0 draw the north-south line
	        	 	if (row > 0){
		        		 //draw the north-south line
			        	 	x1 = x + (width/2);
			        	 	y1 = y - space + height;
			        	 	x2 = x1;
			        	 	y2 = y1 + space - height;
					        g2d.drawLine(x1, y1, x2, y2);
			        	    //draw the north-south weights
					        //g2d.setStroke(prevStk);
			        	    wts = String.valueOf( col_weights[row-1][col] );
		        	 	    x3 = x1 + 10;
		        	 	    y3 = ( y1 + y2 ) / 2;
		        	 	    g2d.drawString(wts, x3, y3); 
			        }
	        	 	
		        	 	//if the prev cell is above draw arrow again with 
		        	 	//bold stroke
		        	 if(prevCellMap.get(Constant.CELL_ABOVE) != null) {
			        		    x1 = x + (width/2);
				        	 	y1 = y - space + height;
				        	 	x2 = x1;
				        	 	y2 = y1 + space - height;
				        	 	g2d.setStroke(boldStk);
						        g2d.drawLine(x1, y1, x2, y2);
				        	    //draw the north-south arrow head
						         x1 = x2 - 5;
						         y1 = y2 - 5;
						         x3 = x2 + 5;
						         y3 = y2 - 5;
						         g2d.drawLine(x1, y1, x2, y2);
						         g2d.drawLine(x2, y2, x3, y3);
						         g2d.setStroke(prevStk);
				      
		        	 }
		        	 if(prevCellMap.get(Constant.CELL_TO_LEFT) != null) {
		        			x1 = x;
				        	y1 = y + (height/2);
				        	x2 = x - space + height ;
				        	y2 = y1;
				        	 	
				        	g2d.setStroke(boldStk);
					        g2d.drawLine(x1, y1, x2, y2);
					        //now draw the arrow heads
					         x2 = x1 - 5;
					         y2 = y1 - 5;
					         x3 = x1 - 5;
					         y3 = y1 + 5;
					         g2d.drawLine(x1, y1, x2, y2);
					         g2d.drawLine(x1, y1, x3, y3);
				        	 g2d.setStroke(prevStk);
		        	 }	        	 
		         }
		                 
		         //draw the score
		         score = String.valueOf( currentCell.getScore() );
		         x1 = x + (width/2) - (score.length()*2);
		         y1 = y + (height/2) ;
		         g2d.drawString(score, x1, y1);
		         x += space;
		         		         	         
		      }
		      if (row == 0)
		      area.width += x;
		      x = 30;
			  y += space;
			  
		   }
	   area.height = y;
	}

	public Cell[][] getMatrix() {
		return matrix;
	}

	public void setMatrix(Cell[][] matrix) {
		this.matrix = matrix;
	}
	

	public JScrollPane getScroller() {
		return scroller;
	}

	public void setScroller(JScrollPane scroller) {
		this.scroller = scroller;
	}

	public int[][] getRow_weights() {
		return row_weights;
	}

	public void setRow_weights(int[][] row_weights) {
		this.row_weights = row_weights;
	}

	public int[][] getCol_weights() {
		return col_weights;
	}

	public void setCol_weights(int[][] col_weights) {
		this.col_weights = col_weights;
	}

	public void scroller(){
		if (area == null) return;
		area.width += 50;
		area.height += 50;
		this.setPreferredSize(area);
		this.revalidate();
		this.repaint();
	}
	
}

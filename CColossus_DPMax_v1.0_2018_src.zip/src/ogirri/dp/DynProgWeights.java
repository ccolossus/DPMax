package ogirri.dp;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class DynProgWeights implements ActionListener{

	private static Cell matrix[][];
	private static int nCols;
	private static int nRows;
	private static int row_weights[][];
	private static int col_weights[][];
	//private static Scanner sc;
	private static int score;
	
	private static String title = "Dynamic Progamming with Weights";
	private static DPGraphics dpg;
	private static JTabbedPane inputPane;
	private static JTextArea txtArea1;
	private static JTextArea txtArea2;
	private static JButton btnOK;
	private static JButton btnCancel;
	
	private static JTextArea txtArea3;
	private static String copyRight;
	
	private String rowWts = "";
	private String colWts = "";
	
	private static JTextField txtRows;
	private static JLabel lblRows;
	private static JTextField txtCols;
	private static JLabel lblCols;
	
	private static String rows = "";
	private static String cols = "";
	
	private Font viewFont = new Font("Verdana", Font.BOLD, 12);
	private static Font bigFont = new Font("Verdana", Font.BOLD, 12);
	private Font smallFont = new Font("Verdana", Font.PLAIN, 10);
	/**
	 * @param args
	 */
	public static void main2(String[] args) {
		// TODO Auto-generated method stub
		

		nCols = Integer.parseInt(
			JOptionPane.showInputDialog("Enter the number of columns")
			);

		nRows = Integer.parseInt(
				JOptionPane.showInputDialog("Enter the number of rows")
		);
		
		matrix = new Cell[nRows][nCols];
		row_weights = new int[nRows][nCols-1];
		col_weights = new int[nRows][nCols];
		
		//now compute the other weights
		initialize();
		fillMatrix();
		System.out.println("The longest path through the matrix as " +
				"obtained by Dynamic Programming is...");
		System.out.println(doTraceback());
		System.out.println("The total length of the path is " + score);
		
	}
	
	
	public static void buildGUI(){
		
        inputPane = new JTabbedPane();
        //JTabbedPane outputPane = new JTabbedPane();
        
        JPanel inputPanel = new JPanel();
        JPanel outputPanel = new JPanel();
        
        //c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
        //c.setLayout(new BorderLayout());
        inputPanel.setLayout(new BorderLayout());
        outputPanel.setLayout(new BorderLayout());
        
        outputPanel.setOpaque(true);
        
        // create the gui components -- Jtextareas and Jlabels
        JLabel jl1 = new JLabel("West-East Weights shown line by line:");
        jl1.setFont(bigFont);
        jl1.setForeground(Color.black);

        Box topPanel = new Box( BoxLayout.Y_AXIS );
        JPanel panel1 = new JPanel( new BorderLayout() );
        txtArea1 = new JTextArea(10, 20);
        txtArea1.setLineWrap(true);
        txtArea1.setWrapStyleWord(true);
        txtArea1.setEditable(false);
        txtArea1.setBackground(Color.white);
        //txtArea1.setFont(new Font("Courier", Font.BOLD, 12));
        txtArea1.setFont(bigFont);
        
        panel1.add(jl1, BorderLayout.NORTH);
        panel1.add(new JScrollPane(txtArea1), BorderLayout.CENTER);
        panel1.setAlignmentX( Component.LEFT_ALIGNMENT );
        topPanel.add( Box.createVerticalStrut(15) );
        topPanel.add( panel1 );

        inputPanel.add( topPanel, BorderLayout.NORTH );
        //c.add( topPanel, BorderLayout.NORTH );
        
        Box bottomPanel  =  new Box( BoxLayout.Y_AXIS );
        JPanel panel2 = new JPanel( new BorderLayout() );

        JLabel jl2 = new JLabel("North-South Weights shown line by line:");
        jl2.setForeground(Color.black);
        jl2.setFont(bigFont);
        
        txtArea2 = new JTextArea(10, 20);
        txtArea2.setLineWrap(true);
        txtArea2.setWrapStyleWord(true);
        txtArea2.setEditable(false);
        txtArea2.setBackground(Color.white);
        //txtArea2.setFont(new Font("Courier", Font.BOLD, 12));
        txtArea2.setFont(bigFont);
        
        bottomPanel.add( Box.createVerticalStrut(15) );
        panel2.add(jl2, BorderLayout.NORTH);
        panel2.add(new JScrollPane(txtArea2), BorderLayout.CENTER);
        panel2.setAlignmentX( Component.LEFT_ALIGNMENT );
        bottomPanel.add( panel2 );

        JPanel panel3 = new JPanel( new GridLayout(4, 1) );
        lblRows = new JLabel("Enter number of rows:");
        lblRows.setFont(bigFont);
        lblRows.setForeground(Color.black);
        txtRows = new JTextField("0", 30);
        txtRows.setFont(bigFont);
        
        lblCols = new JLabel("Enter number of columns:");
        lblCols.setForeground(Color.black);
        lblCols.setFont(bigFont);
        txtCols = new JTextField("0", 30);
        txtCols.setFont(bigFont);
        //bottomPanel.add( Box.createRigidArea(new Dimension(50, 50)) );
        panel3.add(lblRows);
        panel3.add(txtRows);
        panel3.add(lblCols);
        panel3.add(txtCols);
        panel3.setAlignmentX( Component.LEFT_ALIGNMENT );
        bottomPanel.add( panel3 );
        
        //c.add( bottomPanel, BorderLayout.CENTER );
        inputPanel.add( bottomPanel, BorderLayout.CENTER );
        
        Box btnPanel = new Box( BoxLayout.X_AXIS );
        btnOK = new JButton("OK");
        btnOK.setFont(bigFont);
        btnOK.setBackground( new Color(124, 184, 201) );
        btnCancel = new JButton("Cancel");
        btnCancel.setFont(bigFont);
        btnCancel.setBackground( new Color(124, 184, 201) );
        
        btnPanel.add(btnOK);
        btnPanel.add( Box.createHorizontalGlue() );
        btnPanel.add(btnCancel);
        
        //c.add(btnPanel, BorderLayout.SOUTH);
        inputPanel.add(btnPanel, BorderLayout.SOUTH);
        
        btnOK.addActionListener(new DynProgWeights());
        btnCancel.addActionListener(new DynProgWeights());
        
        
        //build output panel
        //txtArea3 = new JTextArea(copyRight);
        txtArea3 = new JTextArea(10, 24);
        txtArea3.setLineWrap(true);
        txtArea3.setWrapStyleWord(true);
        txtArea3.setEditable(false);
        txtArea3.setBackground(Color.white);
        //txtArea3.setFont(new Font("Courier", Font.BOLD, 12));
        txtArea3.setFont(bigFont);
        txtArea3.setText(copyRight);
        outputPanel.add(new JScrollPane(txtArea3));
        
        //now add the graphics drawer
        dpg = new DPGraphics(matrix, row_weights, col_weights);
        
        inputPane.add(inputPanel);
        inputPane.add(outputPanel);
        inputPane.add(dpg);
        
        //dpg.setSize(700, 700);
        inputPane.setTitleAt(0, "Input");
        inputPane.setTitleAt(1, "Output");
        inputPane.setTitleAt(2, "Graphics");
        inputPane.setFont(bigFont);

      }
	
	public static String getTitle() {
		return title;
	}

	public static void setTitle(String title) {
		DynProgWeights.title = title;
	}

	public static void initialize() {
	//get the weights that we need for the whole table 
	String sWeight = "";
	Cell prevCell = null;
	Cell currCell = null;
	Map<String, Cell> prevCellMap = new HashMap<String, Cell>();
	 for (int row = 0; row < matrix.length; row++) {
	      for (int col = 0; col < matrix[row].length; col++) 
	      {
	         matrix[row][col] = new Cell(row, col);
	         if(row == 0 && col > 0){
	        	 currCell = matrix[row][col];
	        	 prevCell = matrix[row][col-1];
	        	 currCell.setPrevCell(prevCell);
	        	 prevCellMap.put(Constant.CELL_TO_LEFT, prevCell);
	        	 currCell.setPrevCellMap(prevCellMap);
	         }
	         
	         if(col == 0 && row > 0){
	        	 currCell = matrix[row][col];
	        	 prevCell = matrix[row-1][col];
	        	 currCell.setPrevCell(prevCell);
	        	 prevCellMap.put(Constant.CELL_ABOVE, prevCell);
	        	 currCell.setPrevCellMap(prevCellMap);
	         }
	         
	      }
	 }
	  
	 rows = "";
	  //fill up the west-east weights
	   for (int row = 0; row < row_weights.length; row++) {
		   
	      for (int col = 0; col < row_weights[row].length; col++) {

	    	  try {
				sWeight = JOptionPane.showInputDialog(null, 
						  "Enter the weight b/w row " + row
							+ " and col " + col + " and row " + row + 
							" col " + (col+1), "West-East Weights",
							JOptionPane.INFORMATION_MESSAGE);
			} catch (HeadlessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return;
			}
	    	  
	    	  
			 try {
				row_weights[row][col] = Integer.parseInt(sWeight);
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return;
			}
			 
			 
			 if(col < nCols - 2)
				 rows += sWeight + " - ";
			 else
				 rows += sWeight;
	      }
	      rows += "\n";
	   }
	   
	   cols = "";
	   String temp = "";
	   //then the north-south weights
	   for (int row = 1; row < col_weights.length; row++) {
		   for (int col = 0; col < col_weights[row-1].length; col++) {

	    	  try {
				sWeight = JOptionPane.showInputDialog(null,
						  "Enter the weight b/w row " + (row-1)
							+ " and col " + col + " and row " + row + 
							" col " + col, "North-South Weights", 
							JOptionPane.INFORMATION_MESSAGE);
			} catch (HeadlessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return;
			}
	    	  
			 try {
				col_weights[row-1][col] = Integer.parseInt(sWeight);
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return;
			}
			 
			 
			 cols += sWeight + "  ";
	      }
		   cols += "\n";
	   }
	   
	   txtArea1.setText(rows);
	   txtArea2.setText(cols);
	   dpg.setMatrix(matrix);
	   dpg.setRow_weights(row_weights);
	   dpg.setCol_weights(col_weights);
	   
	   initializeScores();
		   
	}
	
	public static void initializeScores(){
		//start by setting the first cell score to 0
		matrix[0][0].setScore(0);
		int score = 0;
	
		//set the scores for each cell
		//at first column ie column 0 and row row 
		for(int row = 1; row < nRows; row++){
				score = matrix[row-1][0].getScore() + col_weights[row-1][0];	
				matrix[row][0].setScore(score);
		}
		
		//then set the scores for each cell
		//at first row ie column col and row 0 
		for(int col = 1; col < nCols; col++){
				score = matrix[0][col-1].getScore() + row_weights[0][col-1];	
				matrix[0][col].setScore(score);
		}
		
	}
		
	public static void fillMatrix() {
		int aboveWt, leftWt = 0;
	   for (int row = 1; row < matrix.length; row++) {
	      for (int col = 1; col < matrix[row].length; col++) {
	         Cell currentCell = matrix[row][col];
	         Cell cellAbove = matrix[row - 1][col];
	         Cell cellToLeft = matrix[row][col - 1];
	        
	         aboveWt = col_weights[row-1][col];
	         leftWt = row_weights[row][col-1];

	         fillCell(currentCell, cellAbove, cellToLeft, 
	        		 aboveWt, leftWt);
	      }
	   }
	}
	
	
	public static void fillCell(Cell currentCell, Cell cellAbove, 
			Cell cellToLeft, int aboveWt, int leftWt) {
		   int aboveScore = cellAbove.getScore() + aboveWt;
		   int leftScore = cellToLeft.getScore() + leftWt;
		   Map<String, Cell> prevCellMap = new HashMap<String, Cell>();
		   int cellScore = 0;
		   Cell prevCell;
		   if (leftScore >= aboveScore) {
		      if (leftScore > aboveScore) {
		         cellScore = leftScore;
		         prevCell = cellToLeft;
		         prevCellMap.put(Constant.CELL_TO_LEFT, cellToLeft);
		      } else {
		    	  //ideally if they are the same the two 
		    	  //should both be set as pointers
		         // leftScore == aboveScore
		         cellScore = leftScore;
		         prevCell = cellToLeft;
		         prevCellMap.put(Constant.CELL_TO_LEFT, cellToLeft);
		         prevCellMap.put(Constant.CELL_ABOVE, cellAbove);
		      }
		   } else {//aboveScore > leftScore
		      
		         cellScore = aboveScore;
		         prevCell = cellAbove;
		         prevCellMap.put(Constant.CELL_ABOVE, cellAbove);
		   }
		   currentCell.setScore(cellScore);
		   currentCell.setPrevCell(prevCell);
		   currentCell.setPrevCellMap(prevCellMap);
		 
	}
	

	public static String doTraceback() {
		   StringBuffer buf = new StringBuffer();
		   Cell currentCell = matrix[nRows - 1][nCols - 1];
		   Cell prevCell;
		   int row = 0;
		   int col = 0;
		   score = currentCell.getScore();
		   while(currentCell != null && currentCell.getScore() > 0){ 
			  prevCell = currentCell.getPrevCell();
			  row = currentCell.getRow();
			  col = currentCell.getCol();
			  buf.insert(0, "[" + row + "," + col + "]");
			  currentCell = prevCell;
		      
		   }

		   buf.insert(0, "[0,0]");
		   return buf.toString();
	}
	

	
	public void doDPWeights(){
		matrix = new Cell[nRows][nCols];
		row_weights = new int[nRows][nCols-1];
		col_weights = new int[nRows][nCols];
		
		//now compute the other weights
		initialize();
		fillMatrix();
		String wtsStr = doTraceback();
		String results = "The longest path through the matrix as " +
				"obtained by Dynamic Programming is...\n" + wtsStr
				+ "\n" +
				"The total length of the path is " + score;
		String ruler = "\n=============================================\n";
		txtArea3.append(ruler + results);
	}
	

	
	public static JTabbedPane getInputPane() {
		return inputPane;
	}


	public void actionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		 Component comp = (Component)evt.getSource();
		 if(comp instanceof JButton){
			   JButton btn = (JButton)comp;
			   if(btn.getText() == "OK"){
				   rowWts = txtRows.getText().trim();
				   colWts = txtCols.getText().trim();
				   nRows = Integer.parseInt(rowWts);
				   nCols = Integer.parseInt(colWts);
				   if ( rowWts.length() == 0 ||
						  colWts.length() == 0 || 
						  nRows == 0 || nCols == 0)
					   return;
				   doDPWeights();
			   }else  if(btn.getText() == "Cancel"){
				   System.exit(0);
			   }
		 }
	}
	
}

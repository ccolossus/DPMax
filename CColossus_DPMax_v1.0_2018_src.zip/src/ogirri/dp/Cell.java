package ogirri.dp;

import java.util.Map;

public class Cell {

	private int row;
	private int col;
	private int score;
	private Cell prevCell;
	private Map<String, Cell> prevCellMap;
	   
	public Cell(){
		super();
	}
		
	public Cell(int row, int col) {
		super();
		this.row = row;
		this.col = col;
	}
	
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getCol() {
		return col;
	}
	public void setCol(int col) {
		this.col = col;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public Cell getPrevCell() {
		return prevCell;
	}
	public void setPrevCell(Cell prevCell) {
		this.prevCell = prevCell;
	}

	public Map<String, Cell> getPrevCellMap() {
		return prevCellMap;
	}

	public void setPrevCellMap(Map<String, Cell> prevCellMap) {
		this.prevCellMap = prevCellMap;
	}
	
}
